let targetDate;
let interval;

function setCountdown() {
  const input = document.getElementById("datetime-input").value;
  targetDate = new Date(input);

  if (isNaN(targetDate)) {
    alert("Please select a valid date & time!");
    return;
  }

  const currentTime = new Date();
  
  // Prevent setting a past date/time
  if (targetDate <= currentTime) {
    alert("Please select a future date & time!");
    return;
  }

  updateCountdown();
}

function updateCountdown() {
  if (!targetDate) return;

  const currentTime = new Date();
  const difference = targetDate - currentTime;

  if (difference <= 0) {
    clearInterval(interval);
    document.getElementById("timer").innerText = "The event has started!";
    return;
  }

  const days = Math.floor(difference / (1000 * 60 * 60 * 24));
  const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((difference % (1000 * 60)) / 1000);

  document.getElementById("days").innerText = days;
  document.getElementById("hours").innerText = hours;
  document.getElementById("minutes").innerText = minutes;
  document.getElementById("seconds").innerText = seconds;
}

function startCountdown() {
  if (!targetDate) {
    alert("Please set a countdown first!");
    return;
  }
  
  clearInterval(interval);
  interval = setInterval(updateCountdown, 1000);
}

function stopCountdown() {
  clearInterval(interval);
}
